<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Article;
use App\User;
use Auth;

class myblogController extends Controller
{
    public function overview(){
        $overview = Article::all()->where('user_id','like',Auth::id());
        return view('user-menu.manage-blog',compact('overview'));
    }

    public function addBlogPage(){
        return view('user-menu.add-blog');
    }

    public function addBlogs(Request $request){
        $this->validate($request,[
            'title' => 'required|string|min:4',
            'category' => 'required|string',
            'image' => 'required',
            'description' => 'required|string|min:8'
        ]);

        $article = new Article;

        $fileName = $request->file('image')->getClientOriginalName();
        $filePath = $request->file('image')->storeAs('image', $fileName,'public');
    
        $article->image = $filePath;
        $article->user_id = Auth()->user()->id;
        $article->title = $request->title;
        $article->category_id = $request->get('category');
        $article->description = $request->description;

        $article->save();

        return redirect('/my-blog')->with('success','blog has been published!');

    }

    public function deleteBlogs(Request $request){
        Article::destroy($request->id);
        return redirect()->back()->with('success', 'Blog has been deleted successfully!');
        
    }

    public function profile(){
        $userProfile = User::all()->where('id',Auth::user()->id);
        return view('user-menu.profile',compact('userProfile'));
    }

    public function editProfile(Request $request){
        $this->validate($request,[
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone' => ['required','string','min:9','max:12']
        ]);

        $user = User::find(Auth::user()->id);
        $user->name = $request->name;
        $user->phone = $request->phone;
        $user->email = $request->email;
        $user->save();
        return back()->with('success','Profile has been updated Successfully!');
        
    }
}
