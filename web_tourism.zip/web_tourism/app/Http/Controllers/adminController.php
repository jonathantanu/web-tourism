<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Article;

class adminController extends Controller
{
    public function userPage(){
        $users = User::all()->where('role','like','member');
        return view('admin-menu.edituser',compact('users'));
    }

    public function postPage(){
        $articles = Article::all();
        return view('admin-menu.editpost', compact('articles'));
    }

    public function deleteUser(Request $request){
        User::destroy($request->id);
        return redirect()->back()->with('success', 'User has been deleted successfully!');
    }
}
