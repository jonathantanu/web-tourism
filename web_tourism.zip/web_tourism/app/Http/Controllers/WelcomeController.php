<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Article;

class WelcomeController extends Controller
{
    public function index(){
        $index = Article::paginate(6);
        return view('welcome', compact('index'));
    }

    public function categoryIndex(Request $request){
        $index = Article::where('category_id','like',$request->id)->paginate(6);
        return view('category', compact('index'));
    }
    
    public function detail(Request $request){
        $detail = Article::all()->where('id','like',$request->id);
        return view('detail', compact('detail'));
    }
}
