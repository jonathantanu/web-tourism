@extends('layouts.app')

@section('content')
<div class="container d-flex justify-content-center"> 
    @foreach ($index as $item)
        @if ($loop->first)
            <h3>{{$item->category->name}}</h3>
        @endif  
    @endforeach
</div>
    <div class="container d-flex justify-content-center">
        <div class="row">
            @forelse($index as $art)
                <div class="card mb-3" style="max-width: 530px; margin: 1rem">
                    <div class="row no-gutters">
                        <div class="col-md-4">
                            <img src="{{ url('/storage/'.$art->image) }}" width="150px" height="150px" style="object-fit: cover">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h4 class="card-title text-truncate" style>{{$art->title}}</h5>
                                <h6 class="card-text text-truncate">{{$art->description}}</p>
                                    <a href="/detail/{{$art->id}}" type="submit" class="">See more...</a> <br>
                                <a class="" type="submit" href="/category/{{$art->id}}">Category: {{$art->category->name}}</a>
                            
                            </div>
                        </div>
                    </div>
                </div>
                @empty
                    <div class="card d-flex justify-content-center" style="width:100%; text-align:center;"> 
                        <div class="card-body" style="">
                            There is no article
                        </div>
                    </div>
            @endforelse
        </div>
        <div class="d-flex justify-content-center">
            {{$index->links()}}
        </div>
    </div>
@endsection
