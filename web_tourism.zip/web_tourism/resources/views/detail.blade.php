@extends('layouts.app')
@section('content')
<div class="container d-flex justify-content-center">
    @foreach ($detail as $item)
    <div class="card mb-3">
        <img src="{{ url('/storage/'.$item->image) }}" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">{{$item->name}}</h5>
                <p class="card-text">{{$item->description}}</p>
                <p class="card-text"><small class="text-muted">by {{$item->user->name}}</small></p>
            </div>
      </div>
    @endforeach

</div>
<div class="container d-flex justify-content-start">
    <a href="{{ URL::previous() }}" class="btn btn-outline-success">Go Back</a>
</div>

@endsection