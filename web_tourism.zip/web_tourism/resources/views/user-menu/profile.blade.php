@extends('layouts.app')
@section('content')
@if (\Session::has('success'))
    <div class="alert alert-success d-flex justify-content-center">
      {!! \Session::get('success') !!}
    </div>
@endif
<div class="container d-flex justify-content-center">
    <h1>User Profile</h1><br><br><br>
</div>
    <div class="container d-flex justify-content-center">
        
        @foreach ($userProfile as $item)
            <form action="/profile/edit" method="POST">
            @csrf
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" value="{{$item->name}}" class="form-control" style="width: 500px" id="name" name="name">
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" value="{{$item->email}}" class="form-control" id="name" name="email">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" value="{{$item->phone}}" class="form-control" id="phone" name="phone">
            </div>
            <button type="submit" class="btn btn-success">Update Profile</button>
        </form>
        @endforeach
        <div class="text-bold" style="margin-top:1rem;">
            @if($errors->any())
                {{$errors->first()}}
            @endif
        </div>
       
    </div>
@endsection