@extends('layouts.app')
@section('content')
    <div class="container d-flex justify-content-center">
        <div class="container">
            <div>
                <h2>Add New Blog</h2>
            </div>
            <br>
            <form action="/my-blog/add-blog/" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label for="title"><h3>Title</h3></label>
                    <input type="text" class="form-control" id="title" name="title">
                </div>

                <div class="form-group">
                    <label for="category"><h3>Category</h3></label>
                    <select class="form-control" id="category" name="category">
                        @foreach ($categoryList as $ct)
                            <option value="{!!$ct->id!!}">{{$ct->name}}</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <div class="form-group">
                        <label for="image"><h3>Upload Image</h3></label>
                        <input type="file" class="form-control-file" id="image" name="image">
                      </div>
                </div>

                <div class="form-group">
                    <label for="description"><h3>Story</h3></label>
                    <textarea name="description" id="description" class="form-control" cols="30" rows="10"></textarea>
                </div>

                <button type="submit" id="submit" name="submit" class="btn btn-success">Create</button>
            </form>
            <div class="text-bold" style="margin-top:1rem;">
                @if($errors->any())
                    {{$errors->first()}}
                @endif
            </div>
        </div>
    </div>
@endsection 