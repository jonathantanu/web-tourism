@extends('layouts.app')
@section('content')
@if (\Session::has('success'))
    <div class="alert alert-success d-flex justify-content-center">
      {!! \Session::get('success') !!}
    </div>
@endif
    <div class="container d-flex justify-content-center">
        <div class="card">
            <div class="card-header align-middle">
                <h2>Manage my Blog</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead class="thead-dark">
                      <tr>
                        <th scope="col" style="width: 300px">Title</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        @foreach ($overview as $o)
                            <form action="/my-blog/delete-blog-{{$o->id}}" method="POST">
                                @csrf
                                <tr>
                                    <th class="align-middle">{{$o->title}}</th>
                                    <td><button type="submit" class="btn btn-danger">Delete</button></td>
                                </tr>
                            </form>
                        @endforeach
                    </tbody>
                  </table>
                <div class="container d-flex justify-content-end">
                    <a href="/my-blog/add-new-blog" class="btn btn-success">Add New Post</a>
                </div>    
            </div>
        </div>
    </div>
@endsection