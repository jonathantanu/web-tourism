@extends('layouts.app')
@section('content')
@if (\Session::has('success'))
    <div class="alert alert-success d-flex justify-content-center">
      {!! \Session::get('success') !!}
    </div>
@endif
<div class="container d-flex justify-content-start">
    <h1>Manage Blog Post</h1>
</div>
    <div class="container d-flex justify-content-center">
        <table class="table">
            <thead class="thead-dark">
              <tr>
                <th scope="col" style="">Title</th>
                <th scope="col" style="">User</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
                @foreach ($articles as $o)
                    <form action="/my-blog/delete-blog-{{$o->id}}" method="POST">
                        @csrf
                        <tr>
                            <th class="align-middle">{{$o->title}}</th>
                            <th class="align-middle">{{$o->user->name}}</th>
                            <td><button type="submit" class="btn btn-danger">Delete</button></td>
                        </tr>
                    </form>
                @endforeach
            </tbody>
          </table>
    </div>
@endsection