@extends('layouts.app')
@section('content')
@if (\Session::has('success'))
    <div class="alert alert-success d-flex justify-content-center">
      {!! \Session::get('success') !!}
    </div>
@endif
<div class="container d-flex justify-content-start">
    <h1>Manage User</h1>
</div>
<div class="container d-flex justify-content-center">

    <table class="table">
        <thead class="thead-dark">
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            @foreach ($users as $item)
                <tr>
                    <th>{{$item->name}}</th>
                    <th>{{$item->email}}</td>
                    <th>
                        <form action="/admin/delete-user-{{$item->id}}" method="POST">
                            @csrf
                                <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </th>
                </tr> 
            @endforeach
          
        </tbody>
      </table>
    
</div>

@endsection