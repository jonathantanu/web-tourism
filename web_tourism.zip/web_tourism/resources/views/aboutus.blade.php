@extends('layouts.app')

@section('content')

<div class="container">
    <div class="card bg-dark text-white w-50 container d-flex justify-content-center" style="margin-bottom: 1rem;">
        <img src="/storage/image/wonderful_indonesia.png" class="card-img" alt="...">
      </div>
        <div class="container d-flex justify-content-start">
            <h1>About Us</h1>
        </div>
        <div class="container d-flex justify-content-start">
            <h3>Wonderful Journey is a web-based blog site for Indonesia related topics. Our users will write their travelling experience when enjoying Indonesia tourism and share what they think about it. Our aim is to promote indonesia tourism and to give insight to future tourists about what can they expect in Indonesia.</h3>
        </div>
        <br><br>
        <div class="container d-flex justify-content-center">
            <h5>Social media: Facebook, Twitter, Instagram</h5>
        </div>
</div>


@endsection