<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'WelcomeController@index')->name('Welcome');
Route::get('/about-us','AboutUsController@index')->name('aboutUs');

Auth::routes();

Route::get('/category/{id}','WelcomeController@categoryIndex');
Route::get('/detail/{id}','WelcomeController@detail');

// member only route
Route::get('/my-blog','myblogController@overview')->middleware('member');
Route::get('/my-blog/add-new-blog','myblogController@addBlogPage')->middleware('member');
Route::get('/profile','myblogController@profile')->middleware('member');
Route::post('/profile/edit','myblogController@editProfile')->middleware('member');

Route::post('/my-blog/add-blog','myblogController@addBlogs')->name('add Comment')->middleware('member');
Route::post('/my-blog/delete-blog-{id}','myblogController@deleteBlogs');


// admin only route

Route::get('/admin/user', 'adminController@userPage')->middleware('admin');
Route::get('/admin/post', 'adminController@postPage')->middleware('admin');
Route::post('/admin/delete-user-{id}','adminController@deleteUser')->middleware('admin');
