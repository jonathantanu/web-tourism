<?php

use Illuminate\Database\Seeder;

class ArticleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::Table('articles')->insert([
            ['user_id' => 2,'category_id' => '1','title' => 'Kuta Beach','description' => "Kuta is a tourist area, administratively an urban village (kelurahan), and the capital of Kuta District, Badung Regency, southern Bali, Indonesia. A former fishing village, it was one of the first towns on Bali to see substantial tourist development, and as a beach resort remains one of Indonesia's major tourist destinations. ",'image' => 'image/kuta_beach.jpg'],
            ['user_id' => 2,'category_id' => '2','title' => 'Best Tourist Spot','description' => "Kuta is a tourist area, administratively an urban village (kelurahan), and the capital of Kuta District, Badung Regency, southern Bali, Indonesia. A former fishing village, it was one of the first towns on Bali to see substantial tourist development, and as a beach resort remains one of Indonesia's major tourist destinations. ",'image' => 'image/kuta_beach.jpg'],
            ['user_id' => 2,'category_id' => '3','title' => 'What to eat in Bali','description' => "Kuta is a tourist area, administratively an urban village (kelurahan), and the capital of Kuta District, Badung Regency, southern Bali, Indonesia. A former fishing village, it was one of the first towns on Bali to see substantial tourist development, and as a beach resort remains one of Indonesia's major tourist destinations.",'image' => 'image/kuta_beach.jpg'],
            ['user_id' => 3,'category_id' => '4','title' => '5 Stars hotel you should visit','description' => "Kuta is a tourist area, administratively an urban village (kelurahan), and the capital of Kuta District, Badung Regency, southern Bali, Indonesia. A former fishing village, it was one of the first towns on Bali to see substantial tourist development, and as a beach resort remains one of Indonesia's major tourist destinations. ",'image' => 'image/kuta_beach.jpg'],
            ['user_id' => 3,'category_id' => '5','title' => 'The beauty of Gilimanuk','description' => "Kuta is a tourist area, administratively an urban village (kelurahan), and the capital of Kuta District, Badung Regency, southern Bali, Indonesia. A former fishing village, it was one of the first towns on Bali to see substantial tourist development, and as a beach resort remains one of Indonesia's major tourist destinations.",'image' => 'image/kuta_beach.jpg'],
        ]);
    }
}
