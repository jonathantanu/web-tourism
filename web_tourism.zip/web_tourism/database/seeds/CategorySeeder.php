<?php

use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::Table('categories')->insert([
            ['name' => 'Beach'],
            ['name' => 'Tourism Spot'],
            ['name' => 'Food and Beverages'],
            ['name' => 'Hotel'],
            ['name' => 'Natural View'],
            
        ]);
    }
}
