<?php

use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::Table('users')->insert([
            ['name' => 'Jonathan', 'email' => 'jonathan.andrew@binus.ac.id' , 'phone' => '08123456789','password' => Hash::make("password"),'role' => 'admin'],
            ['name' => 'Budi', 'email' => 'budi@gmail.com' , 'phone' => '08123456789','password' => Hash::make("sayabudi"),'role' => 'member'],
            ['name' => 'Gunawan', 'email' => 'gunawan@yahoo.com' , 'phone' => '08123456789','password' => Hash::make("sayagunawan"),'role' => 'member'],
            
        ]);
    }
}
