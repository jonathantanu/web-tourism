
<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success d-flex justify-content-center">
      <?php echo \Session::get('success'); ?>

    </div>
<?php endif; ?>
<div class="container d-flex justify-content-start">
    <h1>Manage User</h1>
</div>
<div class="container d-flex justify-content-center">

    <table class="table">
        <thead class="thead-dark">
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($item->name); ?></th>
                    <th><?php echo e($item->email); ?></td>
                    <th>
                        <form action="/admin/delete-user-<?php echo e($item->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </th>
                </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </tbody>
      </table>
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\UAS\Web Programming\web_tourism\resources\views/admin-menu/edituser.blade.php ENDPATH**/ ?>