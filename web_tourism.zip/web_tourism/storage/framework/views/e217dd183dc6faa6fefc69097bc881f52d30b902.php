
<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success d-flex justify-content-center">
      <?php echo \Session::get('success'); ?>

    </div>
<?php endif; ?>
<div class="container d-flex justify-content-start">
    <h1>Manage Blog Post</h1>
</div>
    <div class="container d-flex justify-content-center">
        <table class="table">
            <thead class="thead-dark">
              <tr>
                <th scope="col" style="">Title</th>
                <th scope="col" style="">User</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="/my-blog/delete-blog-<?php echo e($o->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <tr>
                            <th class="align-middle"><?php echo e($o->title); ?></th>
                            <th class="align-middle"><?php echo e($o->user->name); ?></th>
                            <td><button type="submit" class="btn btn-danger">Delete</button></td>
                        </tr>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\UAS\Web Programming\web_tourism\resources\views/admin-menu/editpost.blade.php ENDPATH**/ ?>