
<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center">
    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-3">
        <img src="<?php echo e(url('/storage/'.$item->image)); ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($item->name); ?></h5>
                <p class="card-text"><?php echo e($item->description); ?></p>
                <p class="card-text"><small class="text-muted">by <?php echo e($item->user->name); ?></small></p>
            </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<div class="container d-flex justify-content-start">
    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-outline-success">Go Back</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\UAS\Web Programming\web_tourism\resources\views/detail.blade.php ENDPATH**/ ?>