

<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center"> 
    <?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($loop->first): ?>
            <h3><?php echo e($item->category->name); ?></h3>
        <?php endif; ?>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <div class="container d-flex justify-content-center">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card mb-3" style="max-width: 530px; margin: 1rem">
                    <div class="row no-gutters">
                        <div class="col-md-4">
                            <img src="<?php echo e(url('/storage/'.$art->image)); ?>" width="150px" height="150px" style="object-fit: cover">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h4 class="card-title text-truncate" style><?php echo e($art->title); ?></h5>
                                <h6 class="card-text text-truncate"><?php echo e($art->description); ?></p>
                                    <a href="/detail/<?php echo e($art->id); ?>" type="submit" class="">See more...</a> <br>
                                <a class="" type="submit" href="/category/<?php echo e($art->id); ?>">Category: <?php echo e($art->category->name); ?></a>
                            
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="card d-flex justify-content-center" style="width:100%; text-align:center;"> 
                        <div class="card-body" style="">
                            There is no article
                        </div>
                    </div>
            <?php endif; ?>
        </div>
        <div class="d-flex justify-content-center">
            <?php echo e($index->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\UAS\Web Programming\web_tourism\resources\views/category.blade.php ENDPATH**/ ?>