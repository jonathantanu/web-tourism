
<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success d-flex justify-content-center">
      <?php echo \Session::get('success'); ?>

    </div>
<?php endif; ?>
<div class="container d-flex justify-content-center">
    <h1>User Profile</h1><br><br><br>
</div>
    <div class="container d-flex justify-content-center">
        
        <?php $__currentLoopData = $userProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="/profile/edit" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" value="<?php echo e($item->name); ?>" class="form-control" style="width: 500px" id="name" name="name">
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" value="<?php echo e($item->email); ?>" class="form-control" id="name" name="email">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" value="<?php echo e($item->phone); ?>" class="form-control" id="phone" name="phone">
            </div>
            <button type="submit" class="btn btn-success">Update Profile</button>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="text-bold" style="margin-top:1rem;">
            <?php if($errors->any()): ?>
                <?php echo e($errors->first()); ?>

            <?php endif; ?>
        </div>
       
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\UAS\Web Programming\web_tourism\resources\views/user-menu/profile.blade.php ENDPATH**/ ?>