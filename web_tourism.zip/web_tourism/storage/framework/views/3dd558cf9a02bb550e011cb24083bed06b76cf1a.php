
<?php $__env->startSection('content'); ?>
    <div class="container d-flex justify-content-center">
        <div class="container">
            <div>
                <h2>Add New Blog</h2>
            </div>
            <br>
            <form action="/my-blog/add-blog/" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title"><h3>Title</h3></label>
                    <input type="text" class="form-control" id="title" name="title">
                </div>

                <div class="form-group">
                    <label for="category"><h3>Category</h3></label>
                    <select class="form-control" id="category" name="category">
                        <?php $__currentLoopData = $categoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo $ct->id; ?>"><?php echo e($ct->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <div class="form-group">
                        <label for="image"><h3>Upload Image</h3></label>
                        <input type="file" class="form-control-file" id="image" name="image">
                      </div>
                </div>

                <div class="form-group">
                    <label for="description"><h3>Story</h3></label>
                    <textarea name="description" id="description" class="form-control" cols="30" rows="10"></textarea>
                </div>

                <button type="submit" id="submit" name="submit" class="btn btn-success">Create</button>
            </form>
            <div class="text-bold" style="margin-top:1rem;">
                <?php if($errors->any()): ?>
                    <?php echo e($errors->first()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\UAS\Web Programming\web_tourism\resources\views/user-menu/add-blog.blade.php ENDPATH**/ ?>