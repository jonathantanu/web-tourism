
<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success d-flex justify-content-center">
      <?php echo \Session::get('success'); ?>

    </div>
<?php endif; ?>
    <div class="container d-flex justify-content-center">
        <div class="card">
            <div class="card-header align-middle">
                <h2>Manage my Blog</h2>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead class="thead-dark">
                      <tr>
                        <th scope="col" style="width: 300px">Title</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $overview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form action="/my-blog/delete-blog-<?php echo e($o->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <tr>
                                    <th class="align-middle"><?php echo e($o->title); ?></th>
                                    <td><button type="submit" class="btn btn-danger">Delete</button></td>
                                </tr>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                <div class="container d-flex justify-content-end">
                    <a href="/my-blog/add-new-blog" class="btn btn-success">Add New Post</a>
                </div>    
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Onedrive\UAS\Web Programming\web_tourism\resources\views/user-menu/manage-blog.blade.php ENDPATH**/ ?>